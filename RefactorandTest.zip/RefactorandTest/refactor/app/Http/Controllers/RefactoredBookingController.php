<?php

namespace DTApi\Http\Controllers;

use DTApi\Models\Job;
use DTApi\Http\Requests;
use DTApi\Models\Distance;
use Illuminate\Http\Request;
use DTApi\Repository\BookingRepository;
use Illuminate\Support\Facades\Config;

/**
 * Handles requests related to bookings.
 */
class BookingController extends Controller
{

    /**
     * @var BookingRepository
     */
    protected $repository;

    /**
     * BookingController constructor.
     * @param BookingRepository $bookingRepository
     */
    public function __construct(BookingRepository $bookingRepository)
    {
        $this->repository = $bookingRepository;
    }

    /**
     * Returns a list of jobs based on user ID or user type.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function index(Request $request)
    {
        
        
        
        $user_id = $request->get('user_id');
        $authenticated_user = $request->__authenticatedUser;

        if ($user_id) {
            $response = $this->repository->getUsersJobs($user_id);
        } elseif ($authenticated_user->user_type == env('ADMIN_ROLE_ID') || $authenticated_user->user_type == env('SUPERADMIN_ROLE_ID')) {
            $response = $this->repository->getAll($request);
        } else {
            return response(['error' => 'Unauthorized'], 401);
        }

        return response($response);
       
    }

    /**
     * Returns a job based on job ID.
     *
     * @param $id
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function show($id)
    {
        $job = $this->repository->with('translatorJobRel.user')->find($id);

        return response($job);
    }

    /**
     * Stores a new job.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $response = $this->repository->store($request->__authenticatedUser, $data);

        return response($response);

    }

    /**
     * Updates a job based on job ID.
     *
     * @param $id
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function update($id, Request $request)
    {
        $data = $request->all();
        $authenticated_user = $request->__authenticatedUser;

        $response = $this->repository->updateJob($id, array_except($data, ['_token', 'submit']), $authenticated_user);

        return response($response);
    }

    /**
     * Sends an email for an immediate job.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function immediateJobEmail(Request $request)
    {
        $data = $request->all();

        $response = $this->repository->storeJobEmail($data);

        return response($response);
    }

    /**
     * Returns a list of job history based on user ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response|null
     */
    public function getHistory(Request $request)
    {
        $user_id = $request->get('user_id');

        if ($user_id) {
            $response = $this->repository->getUsersJobsHistory($user_id, $request);
            return response($response);
        }

        return null;
    }

    /**
     * Accepts a job based on job ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function acceptJob(Request $request)
    {
        $data = $request->all();
        $authenticated_user = $request->__authenticatedUser;

        $response = $this->repository->acceptJob($data, $authenticated_user);

        return response($response);
    }

    /**
     * Accepts a job based on job ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function acceptJobWithId(Request $request)
    {
        $data = $request->get('job_id');
        $authenticated_user = $request->__authenticatedUser;

        $response = $this->repository->acceptJobWithId($data, $authenticated_user);

        return response($response);
    }

    /**
     * Cancels a job based on job ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function cancelJob(Request $request)
    {
        $data = $request->all();
        $authenticated_user = $request->__authenticatedUser;

        $response = $this->repository->cancelJobAjax($data, $authenticated_user);

        return response($response);
    }

    /**
     * Ends a job based on job ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function endJob(Request $request)
    {
        $data = $request->all();

        $response = $this->repository->endJob($data);

        return response($response);

    }

    /**
     * Marks a job as customer not called based on job ID.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function customerNotCall(Request $request)
    {
        try {
            $data = $request->all();
            $response = $this->bookingRepository->customerNotCall($data);
            return response($response);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to handle customer not calling.");
        }
    }

    /**
     * Gets potential jobs for a user
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function getPotentialJobs(Request $request)
    {
        try {
            $data = $request->all();
            $user = $request->__authenticatedUser;
            $response = $this->bookingRepository->getPotentialJobs($user);
            return response($response);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to get potential jobs.");
        }
    }

    /**
     * Handles distance feed
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function distanceFeed(Request $request)
    {
        try {
            $data = $request->all();
            $jobId = $data['jobid'] ?? null;
            $distance = $data['distance'] ?? null;
            $time = $data['time'] ?? null;
            $sessionTime = $data['session_time'] ?? null;
            $adminComment = $data['admincomment'] ?? null;
            $flagged = $data['flagged'] == 'true' ? 'yes' : 'no';
            $manuallyHandled = $data['manually_handled'] == 'true' ? 'yes' : 'no';
            $byAdmin = $data['by_admin'] == 'true' ? 'yes' : 'no';

            if ($jobId && ($distance || $time)) {
                $affectedRows = Distance::where('job_id', '=', $jobId)->update(array('distance' => $distance, 'time' => $time));
            }

            if ($jobId && ($sessionTime || $adminComment || $flagged || $manuallyHandled || $byAdmin)) {
                if ($data['flagged'] == 'true' && $data['admincomment'] == '') {
                    throw new \Exception("Please add comment.");
                }
                $affectedRows1 = Job::where('id', '=', $jobId)->update(array('admin_comments' => $adminComment, 'flagged' => $flagged, 'session_time' => $sessionTime, 'manually_handled' => $manuallyHandled, 'by_admin' => $byAdmin));
            }

            return response('Record updated!');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to handle distance feed.");
        }
    }

    /**
     * Reopens a job
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function reopen(Request $request)
    {
        try {
            $data = $request->all();
            $response = $this->bookingRepository->reopen($data);
            return response($response);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to reopen job.");
        }
    }

    /**
     * Resends push notifications
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function resendNotifications(Request $request)
    {
        try {
            $data = $request->all();
            $job = $this->bookingRepository->find($data['jobid']);
            $jobData = $this->bookingRepository->jobToData($job);
            $this->bookingRepository->sendNotificationTranslator($job, $jobData, '*');
            return response(['success' => 'Push sent']);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to resend push notifications.");
        }
    }

    /**
     * Resends SMS notifications
     * @param Request $request
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    public function resendSMSNotifications(Request $request)
    {
        try {
            $data = $request->all();
            $job = $this->bookingRepository->find($data['jobid']);
            $jobData = $this->bookingRepository->jobToData($job);
            $this->bookingRepository->sendSMSNotificationToTranslator($job);
            return response(['success' => 'SMS sent']);
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            throw new \Exception("Failed to resend SMS notifications.");
        }
    }
}