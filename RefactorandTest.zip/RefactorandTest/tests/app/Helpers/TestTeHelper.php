<?php

use PHPUnit\Framework\TestCase;

class ExpiryTest extends TestCase
{
    /**
     * Tests that the function returns a string.
     */
    public function testReturnsString()
    {
        $result = willExpireAt('2022-01-01 00:00:00', '2021-12-31 00:00:00');
        $this->assertIsString($result);
    }

    /**
     * Tests that the function returns the correct expiry time when the difference between due time and created time is less than or equal to 90 hours.
     */
    public function testDifferenceLessThan90()
    {
        $result = willExpireAt('2022-01-01 00:00:00', '2021-12-30 00:00:00');
        $this->assertEquals('2022-01-01 00:00:00', $result);
    }

    /**
     * Tests that the function returns the correct expiry time when the difference between due time and created time is less than or equal to 24 hours.
     */
    public function testDifferenceLessThan24()
    {
        $result = willExpireAt('2022-01-01 00:00:00', '2021-12-31 23:00:00');
        $this->assertEquals('2022-01-01 01:30:00', $result);
    }

    /**
     * Tests that the function returns the correct expiry time when the difference between due time and created time is greater than 24 hours and less than or equal to 72 hours.
     */
    public function testDifferenceGreaterThan24()
    {
        $result = willExpireAt('2022-01-01 00:00:00', '2021-12-29 00:00:00');
        $this->assertEquals('2021-12-30 16:00:00', $result);
    }

    /**
     * Tests that the function returns the correct expiry time when the difference between due time and created time is greater than 72 hours.
     */
    public function testDifferenceGreaterThan72()
    {
        $result = willExpireAt('2022-01-01 00:00:00', '2021-12-20 00:00:00');
        $this->assertEquals('2021-12-30 00:00:00', $result);
    }
}