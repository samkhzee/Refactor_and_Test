<?php
use PHPUnit\Framework\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class UserTest extends TestCase
{
    use WithoutMiddleware;
    use DatabaseTransactions;

    public function testCreateOrUpdateWithNewCustomer()
    {
        $request = [
            'role' => 'customer',
            'name' => 'John Doe',
            'email' => 'johndoe@example.com',
            'password' => 'password123',
            'company_id' => '',
            'department_id' => '',
            'consumer_type' => 'paid',
            'customer_type' => 'type1',
            'username' => 'johndoe123',
            'post_code' => '12345',
            'address' => '123 Main St',
            'city' => 'New York',
            'town' => 'Town1',
            'country' => 'USA',
            'reference' => 'yes',
            'additional_info' => 'Additional info',
            'cost_place' => 'Place1',
            'fee' => '10',
            'time_to_charge' => '2 hours',
            'time_to_pay' => '30 days',
            'charge_ob' => 'yes',
            'customer_id' => '123',
            'charge_km' => '5',
            'maximum_km' => '100',
        ];

        $userController = new UserController();
        $result = $userController->createOrUpdate(null, $request);

        $this->assertNotFalse($result);
    }

    public function testCreateOrUpdateWithExistingCustomer()
    {
        $existingUser = User::create([
            'name' => 'Existing Customer',
            'email' => 'existingcustomer@example.com',
            'password' => bcrypt('password123'),
            'role' => 'customer',
            'post_code' => '54321',
            'address' => '456 Main St',
            'city' => 'Los Angeles',
            'town' => 'Town2',
            'country' => 'USA',
            'reference' => 'no',
            'additional_info' => 'Updated additional info',
            'cost_place' => 'Place2',
            'fee' => '15',
            'time_to_charge' => '1 hour',
            'time_to_pay' => '15 days',
            'charge_ob' => 'no',
            'customer_id' => '456',
            'charge_km' => '3',
            'maximum_km' => '50',
        ]);

        $request = [
            'role' => 'customer',
            'name' => 'Updated Customer',
            'email' => 'updatedcustomer@example.com',
            'post_code' => '54321',
            'address' => '456 Main St',
            'city' => 'Los Angeles',
            'town' => 'Town2',
            'country' => 'USA',
            'reference' => 'no',
            'additional_info' => 'Updated additional info',
            'cost_place' => 'Place2',
            'fee' => '15',
            'time_to_charge' => '1 hour',
            'time_to_pay' => '15 days',
            'charge_ob' => 'no',
            'customer_id' => '456',
            'charge_km' => '3',
            'maximum_km' => '50',
        ];

        $userController = new UserController();
        $result = $userController->createOrUpdate($existingUser->id, $request);

        $this->assertNotFalse($result);

    }

    public function testCreateOrUpdateWithNewTranslator()
    {
        $request = [
            'role' => 'translator',
            'name' => 'Jane Smith',
            'email' => 'janesmith@example.com',
            'password' => 'password123',
            'translator_type' => 'type1',
            'worked_for' => 'yes',
            'organization_number' => '12345',
            'gender' => 'female',
            'translator_level' => 'advanced',
            'post_code' => '54321',
            'address' => '456 Main St',
            'address_2' => 'Apt 123',
            'town' => 'Town2',
        ];

        $userController = new UserController();
        $result = $userController->createOrUpdate(null, $request);

        $this->assertNotFalse($result);

    }

    public function testCreateOrUpdateWithExistingTranslator()
    {
        $existingUser = User::create([
            'name' => 'Existing Translator',
            'email' => 'existingtranslator@example.com',
            'password' => bcrypt('password123'),
            'role' => 'translator',
            'translator_type' => 'type2',
            'worked_for' => 'no',
            'gender' => 'male',
            'translator_level' => 'intermediate',
            'post_code' => '12345',
            'address' => '123 Main St',
            'address_2' => 'Suite 456',
            'town' => 'Town1',
        ]);

        $request = [
            'role' => 'translator',
            'name' => 'Updated Translator',
            'email' => 'updatedtranslator@example.com',
            'translator_type' => 'type2',
            'worked_for' => 'no',
            'gender' => 'male',
            'translator_level' => 'intermediate',
            'post_code' => '12345',
            'address' => '123 Main St',
            'address_2' => 'Suite 456',
            'town' => 'Town1',
            // ...
        ];

        $userController = new UserController();
        $result = $userController->createOrUpdate($existingUser->id, $request);

        $this->assertNotFalse($result);
    }
}
