I completely overviewed the code and i found the code level as Intermediate
Many things can be possible in Code to make it beautifull some of the things i have implemented according to my knowledge
Further i found so many things in the code that already created in manner so need for any changes
On the other hand i found the exception handling is missing in so many places and this can make the code vulnerable, we can prevent code by adding exception handling
In the last i summarize the above things and want to say that the Code was good but we can make it Very good or Excellent but unfortunately the time required to do this is greater than your provided time so we will make together after the confirmation of job/Agreement